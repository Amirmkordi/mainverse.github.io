1.   pip install colorama
2.   Trust you vs code