import sqlite3
connection = sqlite3.connect('mydatabase.db')
cursorObj=connection.cursor()