# run with graphic

to run the todo app with graphic you need to run [MAIN.py](MAIN.py)

# for ui download PyQt5 using the following command in cmd : "pip install PyQt5"


# run with CLI


to run the todo app with CLI you need to run [CLI.py](CLI.py)
